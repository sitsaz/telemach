<?php

namespace Stripe;

class BankAccount extends ExternalAccount
{

}
